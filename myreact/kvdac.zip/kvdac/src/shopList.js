import React, { useState } from 'react';
import ShopItem from './shopItem';

function ShopList(props){
    const arr = props.arr;
    const handleDeleteProduct = (product) => {
        const updatedProducts = arr.filter((p) => p !== product);
        props.onAddProduct(updatedProducts);
    };
  
 return (
    <div>
        {arr.map((product, index) => (
            <ShopItem
                key={index}
                data={product}
                onDeleteProduct={handleDeleteProduct}
            />
        ))}
    </div>
);
};

export default ShopList;