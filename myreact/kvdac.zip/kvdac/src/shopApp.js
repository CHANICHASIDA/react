import React,{useState} from 'react'
import ShopInput from './shopInput';

function ShopApp() {

    const [arr,setArr] = useState([]);

  return(
    <ShopInput arr={arr} onAddProduct={setArr} />
      );
}

export default  ShopApp
