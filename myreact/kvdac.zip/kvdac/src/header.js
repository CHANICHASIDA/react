import {Link} from "react-router-dom"

export default function Header(){
    return(
<header className='container-fluid'>
      <h2 className="h2 mx-5">My logo</h2>
      <nav >
        <ul className="d-flex">
          <li className=" mx-5">
            <Link to="/">Home</Link>
          </li>
          <li className=" mx-5">
            <Link to="/about">ShopList</Link>
          </li>  
           <li className=" mx-5">
            <Link to="/employee">Home</Link>
          </li>
          <li className=" mx-5">
            <Link to="/form">Form</Link>
          </li>
        </ul>
      </nav>
    </header>
    )
}