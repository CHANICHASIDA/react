import React, { useRef } from 'react';
import ShopList from './shopList';

function ShopInput(props) {
    let ref1 = useRef();
    let ref2 = useRef();

    const handleAddProduct = () => {
        let prod = {
            prod: ref1.current.value,
            amount: ref2.current.value
        };
        props.onAddProduct([...props.arr, prod]);
    };

    const handleDeleteAllProducts = () => {
        props.onAddProduct([]);
    };

    return (
        <div className='container'>
            <h4>שם מוצר</h4>
            <input ref={ref1} type='text' />
            <h4>כמות מוצר</h4>
            <input ref={ref2} type='number' />
            <br/>
            <button onClick={handleAddProduct} className='btn btn-dark'>
                הוסף מוצר
            </button>
            <button onClick={handleDeleteAllProducts} className='btn btn-dark'>
                מחק מוצר
            </button>
            <ShopList arr={props.arr} onAddProduct={props.onAddProduct} />
        </div>
    );
}

export default ShopInput;