import React, { useState, useRef } from 'react';

function ShopItem(props) {
let nameProd=props.data.prod;
let amount=props.data.amount;

const handleDeleteProduct = () => {
    props.onDeleteProduct(props.data);
};


  return (
    <div className='container'>
        <div className='container'>
            <div className='row border border-dark'>{nameProd - amount }
            <button onClick={handleDeleteProduct}>X</button>
            </div>

        </div>
    </div>
  );
}

export default ShopItem;
